var builder = WebApplication.CreateBuilder(args);

// Add services to the container.
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

var app = builder.Build();

// Configure the HTTP request pipeline.
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.UseHttpsRedirection();

app.MapGet("/namevalidation", (string name) =>
{
    // Validate that the name contains only letters
    if (string.IsNullOrWhiteSpace(name))
    {
        return Results.BadRequest("Name is required.");
    }
    if (!System.Text.RegularExpressions.Regex.IsMatch(name, @"^[a-zA-Z]+$"))
    {
        return Results.BadRequest("Invalid characters in name. Only letters are allowed.");
    }

    return Results.Ok($"Hello, {name}!");
})
.WithName("GetNameValidation")
.WithOpenApi();

app.Run();
